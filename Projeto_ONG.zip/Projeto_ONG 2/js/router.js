const routes = {
    inicio: "<h2>Página Inicial</h2>",
    projetos: "<h2>Projetos Sociais</h2>",
    cadastro: "<h2>Cadastro de Voluntários</h2>"
};

function navigate(page) {
    if (document.getElementById("content")) {
        document.getElementById("content").innerHTML =
            routes[page];
    }
}