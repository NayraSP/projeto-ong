function salvarDados(dados) {
    localStorage.setItem(
        "cadastroUsuario",
        JSON.stringify(dados)
    );
}

function recuperarDados() {
    const dados =
        localStorage.getItem("cadastroUsuario");

    if (dados) {
        return JSON.parse(dados);
    }

    return null;
}