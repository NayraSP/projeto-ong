document.addEventListener("DOMContentLoaded", () => {

    const formulario = document.getElementById("formCadastro");
    const modalConfirmacao = document.getElementById("modalConfirmacao");
    const btnConfirmar = document.getElementById("btnConfirmar");
    const btnCancelar = document.getElementById("btnCancelar");
    const mensagemSucesso = document.getElementById("mensagemSucesso");
    const mensagemErro = document.getElementById("mensagemErro");

    formulario.addEventListener("submit", function(event) {

        event.preventDefault();

        modalConfirmacao.style.display = "flex";

    });

    btnConfirmar.addEventListener("click", function() {

        try {

            modalConfirmacao.style.display = "none";

            mensagemErro.style.display = "none";

            mensagemSucesso.style.display = "block";

            formulario.reset();

            mensagemSucesso.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        } catch (erro) {

            mensagemSucesso.style.display = "none";

            mensagemErro.style.display = "block";

            mensagemErro.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        }

    });

    btnCancelar.addEventListener("click", function() {

        modalConfirmacao.style.display = "none";

    });

});